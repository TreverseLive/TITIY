Hi! Thank you for downloading TITIY: the Tap-It That Insults You!

This project was written and designed by me, Treverse! 
(This program was inspired by Hasbro's game, Bop-It. Original idea as well as form layout credits
should be forwarded their way. In addition, small snippets of code have been inspired by similar
code found on StackOverflow.)

Visit all of my socials at https://treverse.carrd.co
For inquires, please contact treverse.biz@gmail.com

------------------------------------------HOW TO DOWNLOAD:------------------------------------------
1. Go to https://github.com/TreverseLive/TITIY/releases
2. Click on the most recent release
3. Download TITIY-(version).zip
4. Extract the contents to wherever you'd like.
5. Run TITIY.exe to start the game.

-----------------------------------------------RULES:-----------------------------------------------
1. Press the central Tap-It button to start the game!
2. Button Layout:
	- The central button is Tap-It
	- The green object is Flick-It
	- The orange object is Spin-It
	- The yellow object is Twist-It
	- The blue object is Pull-It
3. Each correct click gives you one point. Try to get as high of a score as possible!
4. Have fun!

----------------------------------------------CHANGELOG----------------------------------------------

[1.0.1] - 11-28-22
	- Removed the ability to resize the window, which skewed the game perspective.
	- Lowered the resting time limit and made time decrease faster.
	- Updated game voice lines to be clearer.

[1.0.0] - 11-27-22
	- Initial release.
